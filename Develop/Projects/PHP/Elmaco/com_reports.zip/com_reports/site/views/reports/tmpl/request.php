<?php // no direct access

defined('_JEXEC') or die('Restricted access');
include('header.php');
?>

<table cellspacing="0" cellpadding="0" border="0">

    <tbody>
    <tr>
        <td width="713px">
            <table cellspacing="0" cellpadding="0" border="0">

                <tr>
                    <td colspan="2"><h1 class="h1_gray">заявка №&nbsp;<?=$this->info['reuestId']?></h1></td>
                </tr>
                <tr>
                    <td class="mehanik">Оборудование:</td>
                    <td> <?=$this->info['liftName']?></td>
                </tr>
                <tr>
                    <td class="mehanik">Рег. номер:</td>
                    <td> <?=$this->info['reg_number']?></td>
                </tr>
                <tr>
                    <td class="mehanik">Площадка:</td>
                    <td> <?=$this->info['plName']?> / <?=$this->info['plAddress']?></td>
                </tr>
                <tr>
                    <td class="mehanik">Механик:</td>
                    <td> <?=$this->info['engineer_id']?></td>
                </tr>

                <tr>
                    <td class="mehanik">Дата выполнения:</td>
                    <td><?=$this->info['date_work']?></td>

                </tr>

            </table>

            <table cellspacing="0" cellpadding="0" border="0" class="pers_marg">

                <tr>

                    <td class="pers_description">
                        <r>Описание неисправности</r>
                    </td>

                </tr>

            </table>

            <table cellspacing="0" cellpadding="0" border="0">

                <tr>

                    <td class="pers_problemdisc"><?=$this->info['description_problem']?></td>

                </tr>

            </table>

            <table cellspacing="0" cellpadding="0" border="0" class="pers_marg">
                <tr>

                    <td class="pers_description">
                        <r>Выполненые работы</r>
                    </td>

                </tr>

            </table>

            <table cellspacing="0" cellpadding="0" border="0">

                <tr>

                    <td class="pers_problemdisc"><?=$this->info['work']?></td>

                </tr>

            </table>

            <table cellspacing="0" cellpadding="0" border="0" class="pers_marg">

                <tr>

                    <td class="pers_description">
                        <r>Рекомендации</r>
                    </td>

                </tr>

            </table>

            <table cellspacing="0" cellpadding="0" border="0" class="pers_info_bottom">

                <tr>
                    <td class="pers_problemdisc"><?=$this->info['advice']?></td>
                </tr>

            </table>
            <table cellspacing="0" cellpadding="0" border="0" class="pers_marg">
                <tr>
                    <td><input class="submit_send" type="submit" name="continue" style="cursor: pointer;"
                               value="отправить отзыв об обслуживании"
                               onclick="window.open('http://www.insecom.ru/remarks-offers.html');">
                </tr>
            </table>
        </td>

        <td width="232px" class="pers_right">

        </td>

    </tr>

</table>
<?php include('footer.php');?>






































