<?php // no direct access
defined('_JEXEC') or die('Restricted access');
include('header.php');
?>
<table cellspacing="0" cellpadding="0" border="0">
    <tbody>
    <tr>
        <td width="713px">
            <table>
                <tr>
                    <td><h1 class="h1_gray"><?=$this->title?></h1></td>
                </tr>
                <tr>
                    <td class="personal_arhivdisc">Акты выполненных работ, счетов-фактур и счетов за прошлые
                        периоды,</br>сгруппированные по месяцам в формате pdf.
                    </td>
            </table>
            <table cellspacing="0" cellpadding="0" border="0" class="pers_marg_arh">
                <tr>
                    <td class="personal_arhiv">
                        <?

                        $url=path2url(str_replace('\\','/',$this->_basePath."/file.php"));
                        $months = array("январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь");
                        //echo($url);

                        function path2url($file)
                        {
                            //echo($file."<br/>".JPATH_BASE."<br/>");
                            return JURI::base().str_replace(str_replace('\\','/',JPATH_BASE)."/", '', $file);
                        }
                        foreach ($this->rows as $key => $a) {
                            ?>
                            <table>
                                <tr>
                                    <td colspan="4"><h1 class="h1_arh"><?=$key;?></h1></td>
                                    <?
                                    $i = 0;
                                    foreach ($a as $m => $d) {
                                        if ($i % 4 == 0) echo('</tr><tr>');

                                        echo('<td class="personal_arhmonth" width="170px"><a href="' .$url .'?id=' .$d[0] . '" target="_blank">' . $months[($m - 1)] . '</a></td>');
                                        $i++;
                                    }
                                    ?>
                                </tr>
                            </table><br/><br/>
                            <?
                        }
                        ?>
                    </td>
                </tr>
            </table>
        </td>
        <td width="232px" class="pers_right">
        </td>
    </tr>
</table>
<?php include('footer.php');?>





































